package com.innovation.OPDPrj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpdPrjApplicationTests {

	@Test
	void contextLoads() {
	}

}
