package com.innovation.OPDPrj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpdPrjApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpdPrjApplication.class, args);
	}

}
